data:extend(
{
  {
    type = "bool-setting",
    name = "replace-electronics",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "replace-warfare",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "replace-logistics",
    setting_type = "startup",
    default_value = true,
  },
}
)


