if data.raw.item["basic-transport-belt"] then
	-- Establish patch start-end pieces
	endingPatchPrototype =
	{
		sheet =
		{
		filename = "__base__/graphics/entity/transport-belt/start-end-integration-patches.png",
		width = 40,
		height = 40,
		priority = "extra-high",
		hr_version =
			{
			filename = "__base__/graphics/entity/transport-belt/hr-start-end-integration-patches.png",
			width = 80,
			height = 80,
			priority = "extra-high",
			scale = 0.5
			}
		}
	}
	
	-- Establish generic end pieces
	basicBeltHorizontal =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			scale = 0.5
		}
	}
	basicBeltVertical =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 40,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 80,
			scale = 0.5
		}
	}
	basicBeltEndingTop =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 80,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 160,
			scale = 0.5
		}
	}
	basicBeltEndingBottom =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 120,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 240,
			scale = 0.5
		}
	}
	basicBeltEndingSide =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 160,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 320,
			scale = 0.5
		}
	}
	basicBeltStartingTop =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 200,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 400,
			scale = 0.5
		}
	}
	basicBeltStartingBottom =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 240,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 480,
			scale = 0.5
		}
	}
	basicBeltStartingSide =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png",
		priority = "extra-high",
		width = 40,
		height = 40,
		frame_count = 16,
		y = 280,
		hr_version =
		{
			filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
			priority = "extra-high",
			width = 80,
			height = 80,
			frame_count = 16,
			y = 560,
			scale = 0.5
		}
	}

	-- Patch the Transport Belts
	data.raw["transport-belt"]["basic-transport-belt"].animations.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/black-transport-belt.png"
	data.raw["transport-belt"]["basic-transport-belt"].animations.hr_version =
	{
		filename = "__bob-basic-belt-reskin__/graphics/entity/basic-transport-belt/hr-black-transport-belt.png",
		width = 80,
		height = 80,
		frame_count = 16,
		direction_count = 12,
		scale = 0.5
	}
	
	data.raw["transport-belt"]["basic-transport-belt"].belt_horizontal = basicBeltHorizontal
	data.raw["transport-belt"]["basic-transport-belt"].belt_vertical = basicBeltVertical
	data.raw["transport-belt"]["basic-transport-belt"].ending_top = basicBeltEndingTop
	data.raw["transport-belt"]["basic-transport-belt"].ending_bottom = basicBeltEndingBottom
	data.raw["transport-belt"]["basic-transport-belt"].ending_side = basicBeltEndingSide
	data.raw["transport-belt"]["basic-transport-belt"].starting_top = basicBeltStartingTop
	data.raw["transport-belt"]["basic-transport-belt"].starting_bottom = basicBeltStartingBottom
	data.raw["transport-belt"]["basic-transport-belt"].starting_side = basicBeltStartingSide
	data.raw["transport-belt"]["basic-transport-belt"].ending_patch = endingPatchPrototype
		
	if data.raw.item["basic-underground-belt"] then
		-- Patch the Underground Belts
		data.raw["underground-belt"]["basic-underground-belt"].structure.direction_in.sheet.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-underground-belt/black-underground-belt-structure.png"
		data.raw["underground-belt"]["basic-underground-belt"].structure.direction_in.sheet.hr_version.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-underground-belt/hr-black-underground-belt-structure.png"
		data.raw["underground-belt"]["basic-underground-belt"].structure.direction_out.sheet.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-underground-belt/black-underground-belt-structure.png"
		data.raw["underground-belt"]["basic-underground-belt"].structure.direction_out.sheet.hr_version.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-underground-belt/hr-black-underground-belt-structure.png"
		
		data.raw["underground-belt"]["basic-underground-belt"].belt_horizontal = basicBeltHorizontal
		data.raw["underground-belt"]["basic-underground-belt"].belt_vertical = basicBeltVertical
		data.raw["underground-belt"]["basic-underground-belt"].ending_top = basicBeltEndingTop
		data.raw["underground-belt"]["basic-underground-belt"].ending_bottom = basicBeltEndingBottom
		data.raw["underground-belt"]["basic-underground-belt"].ending_side = basicBeltEndingSide
		data.raw["underground-belt"]["basic-underground-belt"].starting_top = basicBeltStartingTop
		data.raw["underground-belt"]["basic-underground-belt"].starting_bottom = basicBeltStartingBottom
		data.raw["underground-belt"]["basic-underground-belt"].starting_side = basicBeltStartingSide
		data.raw["underground-belt"]["basic-underground-belt"].ending_patch = endingPatchPrototype
	end
	
	if data.raw.item["basic-splitter"] then
		-- Patch the Splitters
		data.raw["splitter"]["basic-splitter"].structure.north.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/black-splitter-north.png"
		data.raw["splitter"]["basic-splitter"].structure.north.hr_version.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/hr-black-splitter-north.png"
		data.raw["splitter"]["basic-splitter"].structure.east.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/black-splitter-east.png"
		data.raw["splitter"]["basic-splitter"].structure.east.hr_version.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/hr-black-splitter-east.png"
		data.raw["splitter"]["basic-splitter"].structure.south.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/black-splitter-south.png"
		data.raw["splitter"]["basic-splitter"].structure.south.hr_version.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/hr-black-splitter-south.png"
		data.raw["splitter"]["basic-splitter"].structure.west.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/black-splitter-west.png"
		data.raw["splitter"]["basic-splitter"].structure.west.hr_version.filename = "__bob-basic-belt-reskin__/graphics/entity/basic-splitter/hr-black-splitter-west.png"

		data.raw["splitter"]["basic-splitter"].belt_horizontal = basicBeltHorizontal
		data.raw["splitter"]["basic-splitter"].belt_vertical = basicBeltVertical
		data.raw["splitter"]["basic-splitter"].ending_top = basicBeltEndingTop
		data.raw["splitter"]["basic-splitter"].ending_bottom = basicBeltEndingBottom
		data.raw["splitter"]["basic-splitter"].ending_side = basicBeltEndingSide
		data.raw["splitter"]["basic-splitter"].starting_top = basicBeltStartingTop
		data.raw["splitter"]["basic-splitter"].starting_bottom = basicBeltStartingBottom
		data.raw["splitter"]["basic-splitter"].starting_side = basicBeltStartingSide
		data.raw["splitter"]["basic-splitter"].ending_patch = endingPatchPrototype
	end
	
	if data.raw["loader"]["basic-loader"] then
		-- Patch the Loader
		data.raw["loader"]["basic-loader"].belt_horizontal = basicBeltHorizontal
		data.raw["loader"]["basic-loader"].belt_vertical = basicBeltVertical
		data.raw["loader"]["basic-loader"].ending_top = basicBeltEndingTop
		data.raw["loader"]["basic-loader"].ending_bottom = basicBeltEndingBottom
		data.raw["loader"]["basic-loader"].ending_side = basicBeltEndingSide
		data.raw["loader"]["basic-loader"].starting_top = basicBeltStartingTop
		data.raw["loader"]["basic-loader"].starting_bottom = basicBeltStartingBottom
		data.raw["loader"]["basic-loader"].starting_side = basicBeltStartingSide
		data.raw["loader"]["basic-loader"].ending_patch = endingPatchPrototype
	end
end