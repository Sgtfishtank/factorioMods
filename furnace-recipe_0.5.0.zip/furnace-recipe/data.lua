require("prototypes.electric-multi-furnace")
require("prototypes.technology.multi-furnace-tech")
